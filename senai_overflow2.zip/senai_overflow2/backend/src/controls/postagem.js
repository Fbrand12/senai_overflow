const Postagem = require("../models/Postagem");
const Aluno = require("../models/Aluno");
const { create } = require("../models/Postagem");

module.exports = {

    async index(req, res) {
        const postagens = await Postagem.findAll({
            include:    {
                association: "Aluno",
                attributes: ["id", "name", "ra"],
            }, 
            order: [["created_at", "DESC"]], 
        });

        res.send(postagens);
    },
    
    async store(req,res) {
        const created_aluno_id = req.alunoId;

        const { title, desc, image, gists } = req.body;

        try {

            const aluno = await Aluno.findByPk(created_aluno_id);

            if(!aluno) {
                res.status(404).send({erro: "Srched aluno."})
            }

            let postagem =  await aluno.createPostagem({
                title,
                desc,
                image,
                gists,     
            });
    
            res.status(201).send(postagem);
        } catch (error) {
            return res.status(500).send({erro: "Publish nao foi add."});
        }
        
    },

    async delete(req,res) {
        // get o id do aluno sgned.
        const token = req.headers.authorization;
        const [Bearer, created_aluno_id] = token.split(" ");

        // get post do id.
        const { id } = req.params;

        // srch o post pelo id pegado.
        let postagem = await Postagem.findByPk(id);

        if(!postagem){
            return res.status(404).send({ erro: "Post not found" });
        }

        if(postagem.created_aluno_id != created_aluno_id){
            return res.status(401).send({ erro: "Not permission for this" });
        }

        // dlt a post.
        await postagem.destroy();

        res.status(204).send();
    },
};