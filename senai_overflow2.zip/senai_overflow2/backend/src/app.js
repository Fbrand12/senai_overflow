const express = require("express");
const rtas = require("./routes");
require("./database");

const app  = express();

// permt body json.
app.use(express.json());

// cadstr das rtas.
app.use(rtas);

module.exports = app;