const express = require ("express");

// create router.

const routes = express.Router();

const alunoCotrl = require ("./controls/aluno");
const postageCotrl = require ("./controls/postagem");


// user routes.
routes.post("/alunos", alunoCotrl.list);
routes.get("/alunos", alunoCotrl.list);
routes.get("/alunos/:id", alunoCotrl.srchId);


// postages routes.
routes.post("/postages", postageCotrl.store);
routes.delete("/postages/:id", postageCotrl.delete);

module.exports = routes;

