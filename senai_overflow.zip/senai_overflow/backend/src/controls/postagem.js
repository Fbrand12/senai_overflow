const Postagem = require("../models/Postagem");

module.exports = {
    async store(req,res) {
        const token = req.headers.authorization;
        const [Bearer, created_aluno_id] = token.split(" ");

        const { title, desc, image, gists } = req.body;

        let post = await Postagem.create ({
            title,
            desc,
            image,
            gists,
            created_aluno_id,
        });

        res.status(201).send(post);
    },

    async delete(req,res) {
        // get o id do aluno sgned.
        const token = req.headers.authorization;
        const [Bearer, created_aluno_id] = token.split(" ");

        // get post do id.
        const { id } = req.params;

        // srch o post pelo id pegado.
        let postagem = await Postagem.findByPk(id);

        if(!postagem){
            return res.status(404).send({ erro: "Post not found" });
        }

        if(postagem.created_aluno_id != created_aluno_id){
            return res.status(401).send({ erro: "Not permission for this" });
        }

        // dlt a post.
        await postagem.destroy();

        res.status(204).send();
    },
};