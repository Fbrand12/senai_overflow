const Sequelize = require("sequelize");
const dbconfig = require("../config/database");
const Aluno = require("../models/Aluno");
const Postagem = require("../models/Postagem");

// create a connection.
const connection =  new Sequelize (dbconfig);

// init as models.
Aluno.init(connection);
Postagem.init(connection);

// init as associates.
Aluno.associate(connection.models);
Postagem.associate(connection.models);

// export connection.
module.exports  = connection;