const { Model, DataTypes } = require('sequelize');

class Postagem extends Model {
    static init (sequelize) {
        super.init({
            title: DataTypes.STRING,
            desc: DataTypes.TEXT,
            image: DataTypes.STRING,
            gists: DataTypes.TEXT,
        },
        {
            sequelize,
            modelName: "postages",
        });
    }

    static associate (models){
        this.belongsTo(models.Aluno, { foreignKey: "created_aluno_id" });
    };
}


module.exports = Postagem;