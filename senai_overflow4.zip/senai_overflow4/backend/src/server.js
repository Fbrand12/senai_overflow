const app = require("./app")

app.listen(3005, () => {
    console.log ("Server on port");
});