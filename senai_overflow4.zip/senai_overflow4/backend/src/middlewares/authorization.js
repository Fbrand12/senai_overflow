const jwt = require("jsonwebtoken");
const authConfg = require("../config/auth.json"); 

module.exports = (req, res, next) => {
    const {authorization} = req.headers;

    if(!authorization)
        res.send(401).send({ erro: "Token dont srched"});
        
    const [Bearer, token] = authorization.split(" ");

    if(!token)

    res.status(401).send({ erro: "Token dont frmted."});

    try{
        const retrno = jwt.verify(token, authConfg.secret);

        req.alunoId = retrno.alunoId;

        return next();
    } catch (erro) {
        res.status(401).send({ erro: "Token invld" })
    }
    

    console.log
}