const { Model, DataTypes } = require('sequelize');

class Aluno extends Model {
    static init (sequelize) {
        super.init({
            ra: DataTypes.STRING,
            name: DataTypes.STRING,
            email: DataTypes.STRING,
            pass: DataTypes.STRING,
        },
        {
            sequelize,
        });
    }

    static associate (models){
        this.hasMany(models.Postagem, { foreignKey: "created_aluno_id" });
        this.hasMany(models.Commentary);
    };
}

module.exports = Aluno;