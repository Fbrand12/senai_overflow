const express = require("express");
const crs = require("cors");
require("./database");
const rtas = require("./routes");

const app  = express();

app.use(crs());

// permt body json.
app.use(express.json());

// cadstr das rtas.
app.use(rtas);

module.exports = app;