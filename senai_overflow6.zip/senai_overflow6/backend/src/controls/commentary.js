const Commentary = require("../models/Commentary");
const Postagem = require("../models/Postagem");

module.exports = {

    async index(req,res){

        const {postId} = req.params;    

        const postagem = await Postagem.findByPk(postId);

        if(!postagem){
            return res.status(404).send({ erro: "Postagem not srched"});
        }

        const commentarys = await postagem.getCommentary({
            include: {
                association: "Aluno",
                attributes: ["id", "name"],
            },
            attributes: ["id", "desc", "created_at"],
            order: [["created_at", "ASC"]],
        });
        
        res.send(commentarys);

    },

    async store(req,res){

        const alunoId = req.alunoId;

        const {postId} = req.params;

        const {desc} = req.body;

        const postagem = await Postagem.findByPk(postId);
        
        if(!postagem){
            return res.status(404).send({ erro: "Postagem not srched"});
        }

        let commentary = await postagem.createCommentary({
            desc,
            aluno_id: alunoId,
        });

        commentary = commentary.dataValues;
        commentary.postagem_id = commentary.PostagemId;
        delete commentary.PostagemId;
        delete commentary.AlunoId; 

        res.status(201).send(commentary);

    },
};