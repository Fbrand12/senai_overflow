const express = require ("express");

// create router.

const routes = express.Router();

const authorizationMid = require("./middlewares/authorization");

const alunoCotrl = require ("./controls/aluno");
const postageCotrl = require ("./controls/postagem");
const commentaryCotrl = require ("./controls/commentary");
const sessionCotrl = require ("./controls/session");

// pblic routes.

routes.post("/session", sessionCotrl.store);
routes.post("/alunos", alunoCotrl.list);

// middleware das rtas.
routes.use(authorizationMid);

// user routes.
routes.get("/alunos", alunoCotrl.list);
routes.get("/alunos/:id", alunoCotrl.srchId);


// postages routes.
routes.get("/postages", postageCotrl.index);
routes.post("/postages", postageCotrl.store);
routes.delete("/postages/:id", postageCotrl.delete);

// commentaries routes.
routes.get("/postages/:postId/commentary", commentaryCotrl.index);
routes.post("/postages/:postId/commentary", commentaryCotrl.store);

module.exports = routes;

