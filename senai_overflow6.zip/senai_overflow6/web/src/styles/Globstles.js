import { createGlobalStyle } from "styled-components";

export const GlobalStyle = createGlobalStyle`
    
    * {
        margin: 0;
        paddind: 0;
        outline: 0;
    }

    body: {
        font-family: arial;
        background-color: blue;
    }

    input {
        background-color: white;
        font-size: 15px;
        border: 1px solid white;
        padding: 10px;
        font-weight: bold;
        height: 30px;
        transition: background-color 0.2s;
    }

    label {
        color: white;
        letter-spacing: 2px;
        font-size: 20px;
    }

    input, button {
        :hover {
            background-color: blue;
            cursor: pointer;
        }
    }

    button {
        padding: 10px;
        font-family: arial;
        font-size: 18px;
        letter-spacing: 2px;
        background-color: white;
        border: 1px solid white;

        transition: background-color 0.2s;

        :active {
            color: blue;
            border: blue;
        }
    }
`