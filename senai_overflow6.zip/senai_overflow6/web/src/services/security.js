import { api } from "./api";

const PASSALUNO = "@aluno";

export const signIn = (aluno) => {
    localStorage.setItem(PASSALUNO, JSON.stringfy(aluno));

    api.defaults.headers.common['Authorization'] = `Bearer ${aluno.token}`;
}

export const signOut = () => {
    localStorage.clear();

    api.defaults.headers.common['Authorization'] = undefined;
}

export const getAluno = () => {
    const { aluno } = JSON.parse(localStorage.getItem(PASSALUNO));

    return aluno;
}

export const isSignedIn = () => {
    const aluno = JSON.parse(localStorage.getItem(PASSALUNO));

    if (aluno) {
        api.defaults.headers.common['Authorization'] = `Bearer ${aluno.token}`;
    }
    if (aluno) {
        return true;
    } else {
        return false;
    }
};