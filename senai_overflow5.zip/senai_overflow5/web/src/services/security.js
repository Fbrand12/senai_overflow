const PASSALUNO = "@aluno";

export const signIn = (aluno) => {
    localStorage.setItem(PASSALUNO, JSON.stringfy(aluno));
}

export const signOut = () => {
    localStorage.clear();
}

export const isSignedIn = () => {
    const aluno = JSON.parse(localStorage.getItem(PASSALUNO));

    if (aluno) {
        return true;
    } else {
        return false;
    }
};