import React, { useState } from "react";

import  { Container, ImageCropped, Form, Title, SubTitle, InptGrp, Button } from "./styles"

import pht from "../../assets/image.jpg"
import { api } from "../../services/api";
import { useHistory } from "react-router-dom";
import { signIn } from "../../services/security";

const FormLogin = (props) => {

    const hstr = useHistory();

    const [alunoLogin, setAlunoLogin] = useState({
        email: "",
        pass: "",
    });

    const login = async (e) => {
        e.preventDefault();

        try {
        const returno =  await api.post("/session", alunoLogin);

        if(returno === 201){
            signIn(returno.data);
            return hstr.push("/home");
        }
        } catch (erro) {
            if(erro.response) {
                return window.alert(erro.response.data.erro);
            }

            window.alert("Erro");
        }

    };

    const handlerInput = (e) => {
        setAlunoLogin({...alunoLogin, [e.target.id]: e.target.value});
    }

    return (
        <Form onSubmit={login}>
                    <Title>
                        Senai Overflow
                    </Title>
                    <SubTitle>
                        SubTitle
                    </SubTitle>
                    <InptGrp>
                        <label>Email</label>
                        <input type="email" id="email" value={alunoLogin.email} onChange={handlerInput} placeholder="Insira o email" required/>
                    </InptGrp>
                    <InptGrp>
                        <label>Pass</label>
                        <input type="password" id="pass" value={alunoLogin.pass} onChange={handlerInput} placeholder="Insira sua pass" required/>
                    </InptGrp>
                    <Button type="submit">
                        Login
                    </Button>
                    <Button type="button" onClick={() => {
                        props.mstrForm("register")
                    }}>
                        Register
                    </Button>
                </Form>
    );
}

const FormRegister = (props) => {


    const [alunoRegister, setAlunoRegister] = useState({
        ra: "",
        name: "",
        email: "",
        pass: "",
    });

    const register = async (e) => {
        e.preventDefault();

        try {
        const returno =  await api.post("/alunos", alunoRegister);

        if(returno.status === 201){
                window.alert("Registrado")
        }
        } catch (erro) {
            if(erro.response) {
                return window.alert(erro.response.data.erro);
            }

            window.alert("Erro");
        }

    };

    const handlerInput = (e) => {
        setAlunoRegister({...alunoRegister, [e.target.id]: e.target.value});
    }

    return (
        <Form onSubmit={register}>
                    <Title>
                        Senai Overflow
                    </Title>
                    <SubTitle>
                        SubTitle
                    </SubTitle>
                    <InptGrp>
                        <label>RA</label>
                        <input type="number" id="ra" value={alunoRegister.ra} onChange={handlerInput} placeholder="Insira o ra" required/>
                    </InptGrp>
                    <InptGrp>
                        <label>Name</label>
                        <input type="text" id="name" value={alunoRegister.name} onChange={handlerInput} placeholder="Insira o name" required/>
                    </InptGrp>
                    <InptGrp>
                        <label>Email</label>
                        <input type="email" id="email" value={alunoRegister.email} onChange={handlerInput} placeholder="Insira o email" required/>
                    </InptGrp>
                    <InptGrp>
                        <label>Pass</label>
                        <input type="password" id="pass" value={alunoRegister.pass} onChange={handlerInput} placeholder="Insira o pass" required/>
                    </InptGrp>
                    <Button type="submit">
                        Register
                    </Button>
                    <Button type="button" onClick={() => {
                        props.mstrForm("login")
                    }}>
                        Login
                    </Button>
                </Form>
    );
}

const Login = () => {

    const [mstrForm, setMstrForm] = useState("login");

    return  (
        <>
            <Container>
                <ImageCropped>
                    <img src={pht} alt="Image"/>
                </ImageCropped>
                {mstrForm === "login" ? (
                    <FormLogin mstrForm={setMstrForm} />
                ) : (
                    <FormRegister mstrForm={setMstrForm}/>
                )}
            </Container>
        </>
    )
}  

export default Login;