import React from 'react';

import { FiGithub, FiLogOut } from "react-icons/fi"
import './style.css';

import ftProfile from "../../assets/image1.png"
import ftPost from "../../assets/image2.jpg"
import { useHistory } from 'react-router-dom';

function Home() {

    const hstr = useHistory();

    return (
        <div className="container">
        <header className="header">
            <div><p> Senai Overflow </p></div>
            <div><input type="search" placeholder="Srch aq"></input></div>
            <div><button className="btnExt" onClick={() => {
                signOut();
                hstr.replace("/");
            }}>
                Ext <FiLogOut/></button></div>
        </header>
        <div className="content">
            <section className="profile">
                <img src={ftProfile} alt="ftProfile"/>
                <a href="a"> Edt ft</a>
                <strong> Name </strong>
                <p> Name Name</p>
                <strong> Email </strong>
                <p> Email Email</p>
                <strong> Ra </strong>
                <p> Ra Ra</p>
            </section>
            <section className="feed">
                <div className="crdPost">
                    <header>
                        <img src={ftProfile} alt="ftProfile"/>
                        <strong> Name </strong>
                        <p> postage dt </p>
                        <FiGithub className="icn" size={18}/>
                    </header>
                    <body>
                        <strong>
                            Title
                        </strong>
                        <p>
                            Desc
                        </p>
                        <img src={ftPost} alt="ftPost"/>
                    </body>
                    <footer>
                        <h1> Comnts </h1>
                        <section>
                            <header>
                            <img src={ftProfile} alt="ftPost"/>
                            <strong> Name </strong>
                            <p> postage dt e hr </p>
                            </header>
                            <p>
                                Desc comnts
                            </p>
                        </section>
                    </footer>
                </div>
            </section>
        </div>
    </div>
    )
}

export default Home;