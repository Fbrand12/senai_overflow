const { Op } = require ("sequelize");
const Aluno = require("../models/Aluno");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const authConfg = require("../config/auth.json");


module.exports = {

    async list(req,res){
        
        const alunos = await Aluno.findAll();

        res.send(alunos);
    },

    // srch aluno pelo id no db.

    async srchId(req, res){
        const { id } = req.params;

        // srch aluno pelo id.
        let aluno = await Aluno.findByPk(id, { raw: true });

        // verify se o aluno foi srchd.
        if(!aluno) {
            return res.status(404).send({ erro: "Aluno search fld"});
        }

        delete aluno.pass;

        // return aluno do db.
        res.send(aluno);
    },


    // insert no db.
    async store(req,res){
        const { ra, name, email, pass } = req.body;
        // verify aluno no db.
        // select from alunos where ra.
        let aluno = await Aluno.findOne({
            where: {
                [Op.or]: [{ ra: ra }, { email: email }],
            },
        });

        if(aluno) {
            return res.status(400).send({error: "Alryght regstrd"})
        }

        const passCript = await bcrypt.hash(senha, 10)
        
        aluno = await Aluno.create({ ra, name, email, pass: passCript });

        const token = jwt.sign({ alunoId: aluno.id}, authConfg.secret)

        res.status(201).send({
            aluno: {
            alunoId: aluno.id,
            name: aluno.name,
            ra: aluno.ra,
        },
            token
        });
    },
    update(){},
    delete(){},
};