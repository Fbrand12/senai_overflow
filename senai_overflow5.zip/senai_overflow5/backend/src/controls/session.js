const Aluno = require("../models/Aluno");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const authConfg = require("../config/auth.json");

module.exports = {
    async store(req, res){
        const { email, pass } = req.body;

        // verify aluno and pass.
        const aluno = await Aluno.findOne({
            where: {
                email: email,
            },
        });

        if(!aluno || !await bcrypt.compare(pass, aluno.pass)){
            return res.status(401).send({ erro: "User or pass incrt." });   
        }

        const token = jwt.sign({ alunoId: aluno.id }, authConfg.secret);

        res.status(201).send({
            aluno: {
            alunoId: aluno.id,
            name: aluno.name,
            ra: aluno.ra,
        },
            token
        }); 
    },
};