import React, { useEffect, useState } from 'react';

import { FiGithub, FiLogOut } from "react-icons/fi"
import './style.css';

import ftProfile from "../../assets/image1.png"
import ftPost from "../../assets/image2.jpg"
import { useHistory } from 'react-router-dom';
import { getAluno } from '../../services/security';

const CrdPost = ({post}) => {

    const [mstrCommentary, setMstrCommentary] = useState(false);
    const [commentaries, setCommentaiyes] = useState([]);

    const ldCommentaries = () => {
        
        try {
            if(!mstrCommentary) {
                const returno = await api.get(`/postages/${post.id}/commentaries`);    
                setCommentaries(returno.data);
            }

            setMstrCommentary(!mstrCommentary);
        } catch {
            console.log(erro);
        }
    };

    return (
        <div className="crdPost">
                    <header>
                        <img src={ftProfile} alt="ftProfile"/>
                        <strong> {post.Aluno.name} </strong>
                        <p> {post.createdAt} </p>
                        {post.gists && (<FiGithub className="icn" size={18}/>)};
                    </header>
                    <body>
                        <strong>
                            {post.title}
                        </strong>
                        <p>
                            {post.desc}
                        </p>
                        <img src={ftPost} alt="ftPost"/>
                    </body>
                    <footer>
                        <h1 onClick={ldCommentaries}> Comnts </h1>
                        {mstrCommentary && (
                        <>
                        {commentaries.length === 1 && (<p> Comment </p>) }
                        {commentaries.map((cmnt) => (
                        <section>
                            <header>
                                <img src={ftProfile} alt="ftPost"/>
                                <strong> {post.Aluno.name} </strong>
                                <p> {cmnt.created_at} </p>
                            </header>
                            <p>
                                {cmnt.desc}
                            </p>
                        </section>
                        ))}
                        </>
                        )}
                        
                    </footer>
                </div>
    )
};

const NvPostagem = ({setMstrNvPostagem}) => {

    const [nvPostagem, setMstrNvPostagem] = useState({
        title: "",
        desc: "",
        gists: "",
    })

    const fch = () => {
        const {title, desc, gists} = nvPostagem;

        if((title || desc || gists) && !window.confirm("Fchr")){
            return
        }

        setMstrNvPostagem(false);
    };
    
    const hndInpt = (e) => {
        setNvPostagem({...nvPostagem, [e.target.id]: e.target.value});
    }
    

    return (<Popup>
        <form className="nvPostagem">
            <h1> Post on this </h1>
            <label> Ttle </label>
            <input type="text" id="title" placeholder="Abt post is" onChange={hndInpt}/>
            <label> Desc </label>
            <textarea id="desc" placeholder="Desc" onChange={hndInpt}></textarea>
            <label> Gists </label>
            <input type="text" id="gists" placeholder="Gists" onChange={hndInpt}></input>
            <label> Image </label>
            <input type="file"/>
            <img src="preview"/>
            <button> Send </button>  
        </form>
    </Popup>)
}

function Home() {

    const hstr = useHistory();
    const [mensage, setMensage] = useState("");
    const [postages, setPostages] = useState([]);
    const [exbNvPostages, setexbNvPostages] = useState(false);

    useEffect(() => {

        const ldPostages = async () => {
            try {
                const returno = await api.get("/postages");
                setPostages(returno.data);
            } catch {
                console.log(erro);
                return props.setMensage(error.response.data.erro);
            }
            setMensage("Algm erro, tnt nvmnt");
        }

        ldPostages();

    }, []);

    const alunoSession = getAluno();
    
    return (
        <div className="container">
            <Alerts mensage={mensage} setMensage={setMensage} tipo="erro"/>
            {exbNvPostages && <NvPostagem setMstrCommentary={setMstrCommentary}/>}
        <header className="header">
            <div><p> Senai Overflow </p></div>
            <div><input type="search" placeholder="Srch aq"></input></div>
            <div><button className="btnExt" onClick={() => {
                signOut();
                hstr.replace("/");
            }}>
                Ext <FiLogOut/></button></div>
        </header>
        <div className="content">
            <section className="profile">
                <img src={ftProfile} alt="ftProfile"/>
                <a href="a"> Edt ft</a>
                <strong> Name </strong>
                <p> {alunoSession.name}</p>
                <strong> Ra </strong>
                <p> {alunoSession.ra}</p>
            </section>
            <section className="feed">
                {postages.map((post) => (
                    <CrdPost post={post}/>
                ))}
            </section>
            <section className="actns">
                <button onClick={() => {
                    setexbNvPostages(true);
                }}> Nv Postagem </button>
            </section>
        </div>
    </div>
    )
}

export default Home;