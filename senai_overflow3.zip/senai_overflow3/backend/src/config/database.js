module.exports = {
    dialect: "mysql",
    host: "localhost",
    username: "root",
    password: "",
    database: "senai_overflow",
    define: {
        timestamp: true,
        underscored: true,
    },
};