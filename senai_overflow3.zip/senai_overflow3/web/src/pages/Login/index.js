import React from "react";

import  { Container, ImageCropped, Form, Title, SubTitle, InptGrp, Button } from "./styles"

import pht from "../../assets/image.jpg"

const Login = () => {
    return  (
        <>
            <Container>
                <ImageCropped>
                    <img src={pht} alt="Image" />
                </ImageCropped>
                <Form>
                    <Title>
                        Senai Overflow
                    </Title>
                    <SubTitle>
                        SubTitle
                    </SubTitle>
                    <InptGrp>
                        <label>Email</label>
                        <input type="email" placeholder="Insira o email"/>
                    </InptGrp>
                    <InptGrp>
                        <label>Pass</label>
                        <input type="password" placeholder="Insira sua pass"/>
                    </InptGrp>
                    <Button>
                        Login
                    </Button>
                    <Button>
                        Register
                    </Button>
                </Form>
            </Container>
        </>
    )
}  

export default Login;