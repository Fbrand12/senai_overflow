import React, { useState } from "react";

import Login from "./pages/Login";
import  { GlobalStyle } from "./styles/Globstles"

function App() {
  return (
    <>
        <Login />
        <GlobalStyle />
    </>
  );
}

export default App;
