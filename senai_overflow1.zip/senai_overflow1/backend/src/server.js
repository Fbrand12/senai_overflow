const app = require("./app")

/* const pes = {
    name: "Name",
    sbr: "Names",
    idd: 3
}

app.get("/", (request,response) => {
    response.send(pes);
}); */



app.listen(3000, () => {
    console.log ("Server on port");
});