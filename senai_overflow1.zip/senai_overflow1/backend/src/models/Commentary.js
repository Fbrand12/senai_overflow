const { Model, DataTypes } = require("sequelize");

class Commentary extends Model {
    static init(sequelize){
        super.init(
            {
                desc: DataTypes.TEXT,
            },
            {
                sequelize,
            }
        );
    }

    static associate(models){
        this.belongsTo(models.Postagem);
        this.belongsTo(models.Aluno);
    }
};

module.exports = Commentary;