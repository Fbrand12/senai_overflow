const Commentary = require("../models/Commentary");

module.exports = {

    async store (req, res){
        
    }
}